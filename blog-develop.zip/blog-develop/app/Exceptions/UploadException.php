<?php

namespace App\Exceptions;

class UploadException extends \Exception
{
    //
}
