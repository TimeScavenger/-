export default [{
  path: 'files',
  name: 'dashboard.file',
  component: () => import('./File')
}]
