export default [{
  path: 'visitors',
  name: 'dashboard.visitor',
  component: () => import('./Visitor')
}]
