export default [{
  path: 'system',
  name: 'dashboard.system',
  component: () => import('./System')
}]
