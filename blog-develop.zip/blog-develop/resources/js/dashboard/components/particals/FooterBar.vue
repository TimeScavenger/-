<template>
  <footer>
    <div class="copy-right text-center">
      <span>© Pig Jian 2016. All rights reserved. </span><a class="item" href="http://www.miitbeian.gov.cn/">粤ICP备16020344号-1</a>
    </div>
  </footer>
</template>
