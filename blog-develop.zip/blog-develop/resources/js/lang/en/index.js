import sidebar from './sidebar'
import page from './page'
import table from './table'
import form from './form'
import permission from './permission'

export default {
  sidebar,
  page,
  table,
  form,
  permission
}
