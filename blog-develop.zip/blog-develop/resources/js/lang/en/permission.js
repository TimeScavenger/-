export default {
  user: 'User Permissions',
  article: 'Article Permissions',
  discussion: 'Discussion Permissions',
  comment: 'Comment Permissions',
  file: 'File Permissions',
  tag: 'Tag Permissions',
  category: 'Category Permissions',
  link: 'Link Permissions',
  role: 'Role Permissions',
  visitor: 'Visitor Permissions',
  system: 'System Permissions',
}
