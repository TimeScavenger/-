export default {
  dashboard: 'Dashboard',
  user: 'Users',
  article: 'Articles',
  discussion: 'Discussion',
  comment: 'Comments',
  tag: 'Tags',
  file: 'Files',
  category: 'Categories',
  link: 'Links',
  visitor: 'Visitors',
  role: 'Roles',
  system: 'Systems',
  modules: {
    base: 'Base Module',
    content: 'Content Module',
    system: 'System Module'
  }
}
