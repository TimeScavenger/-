export default {
  user: '用户模块',
  article: '文章模块',
  discussion: '讨论模块',
  comment: '评论模块',
  file: '文件模块',
  tag: '标签模块',
  category: '分类模块',
  link: '友链模块',
  role: '角色模块',
  visitor: '访问模块',
  system: '系统模块',
}
