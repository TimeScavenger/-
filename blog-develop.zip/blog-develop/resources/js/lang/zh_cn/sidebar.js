export default {
  dashboard: '面板',
  user: '用户管理',
  article: '文章管理',
  discussion: '讨论管理',
  comment: '评论管理',
  tag: '标签管理',
  file: '文件管理',
  category: '分类管理',
  link: '友链管理',
  visitor: '访问列表',
  role: '角色列表',
  system: '系统配置',
  modules: {
    base: '基础模块',
    content: '内容模块',
    system: '系统模块'
  }
}
