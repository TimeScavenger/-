export default {
  dashboard: 'Дашборд',
  user: 'Пользователи',
  article: 'Статьи',
  discussion: 'Обсуждения',
  comment: 'Комментарии',
  tag: 'Теги',
  file: 'Файлы',
  category: 'Категории',
  link: 'Ссылки',
  visitor: 'Посетители',
  role: 'Роли',
  system: 'Система',
  modules: {
    base: 'Базовый модуль',
    content: 'Модуль контента',
    system: 'Системный модуль'
  }
}
