import en from './en/index'
import ru from './ru/index'
import zh_cn from './zh_cn/index'

export default {
  en,
  ru,
  zh_cn
}
