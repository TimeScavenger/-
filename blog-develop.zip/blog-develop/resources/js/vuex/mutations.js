export const toggle = state => {
  return state.sidebar.opened = !state.sidebar.opened
}
