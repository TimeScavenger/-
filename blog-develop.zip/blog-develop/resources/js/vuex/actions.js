export const toggle = ({ commit }) => commit('toggle')
